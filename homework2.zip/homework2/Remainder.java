
package remainder;

public class Remainder {

   
    public static void main(String[] args) {
    
     int X = 15;
    int Y = 4;
     
     int Remainder = X%Y;
     System.out.println(Remainder);
   
  
  
    }
    
}
