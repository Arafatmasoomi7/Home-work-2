
package equation;
import java.util.Scanner;

public class Equation {

    
    public static void main(String[] args) {
     
        Scanner input = new Scanner(System.in);
        
        double a, b, c, root1, root2;
        System.out.println("please enter value for a");
        a = input.nextDouble();
        
         System.out.println("please enter value for b");
         b = input.nextDouble();
         
         System.out.println("please enter value for c");
         c = input.nextDouble();
         
         root1 = (-b-(Math.sqrt(b*b*-4*a*c))) / (2*a);
          root2 = (-b+(Math.sqrt(b*b*-4*a*c))) / (2*a);
          
          System.out.println("the value of root1 is");
          System.out.println(root1);
          System.out.println("the value of root2 is");
          System.out.println(root2);
    }
    
}
