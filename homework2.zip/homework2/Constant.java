
package constant;


public class Constant {

   
    public static void main(String[] args) {
    
        final double PI = 3.14159;
        
        System.out.println(PI);
    }
    
}
