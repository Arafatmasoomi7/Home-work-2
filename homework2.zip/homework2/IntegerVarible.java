
package integer.varible;


public class IntegerVarible {

    
    public static void main(String[] args) {
    
        int X;
        X = 5;
        
        System.out.println(X);
        
    }
    
}
