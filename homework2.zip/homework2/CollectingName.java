
package coiiecting.name;


public class CoiiectingName {

    
    public static void main(String[] args) {
        
        String name = "arafat";
        String lastname = "masoomi";
        
        System.out.println(name + lastname);
        
    }
    
}
