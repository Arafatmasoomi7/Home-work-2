
package pkgdouble.pkgint;


public class DoubleInt {

    
    public static void main(String[] args) {
        
        int x = (int) (9.7);
        System.out.println("the int value of 9.7 is");
        System.out.println(x);
        
        double A = 9.7;
        System.out.println("the double value of 9.7 is");
        System.out.println(A);
        
    }
    
}
