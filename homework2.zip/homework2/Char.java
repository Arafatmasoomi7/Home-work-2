
package pkgchar;

public class Char {

   
    public static void main(String[] args) {
      char letter ='A' ;
      int num = 100;
        System.out.println("the letter is " + letter);
        System.out.println("the num is " +num);
      
      
     
    }
    
}
