
package erea.of.aquara;
import java.util.Scanner;

public class Circleerea {

   
    public static void main(String[] args) {
   Scanner input = new Scanner(System.in);
   
   double R, area;
  
    System.out.println("please enter value for R");
    R = input.nextDouble();
    
    area = 3.14*R*R;
    System.out.println("the value of area is ");
    System.out.println(area);
    }
    
}
