
package commpound.asig;

public class CommpoundAsig {

    
    public static void main(String[] args) {
     
        int x = 5;
        x +=3;
        System.out.println(x);  
        x -=2;
        System.out.println(x);
        x *=4;
        System.out.println(x);
        x /=5;
        System.out.println(x);   
        x %=3;
        System.out.println(x);
        
       
        
    }
    
}
