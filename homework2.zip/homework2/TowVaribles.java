
package tow.varibles;


public class TowVaribles {

    public static void main(String[] args) {
      
        double A = 10;
        double B = 20;
        double X;
        
        X = A+B;
        System.out.println("the value of A+B is");
       System.out.println(X);
       
        X = A-B;
        System.out.println("the value of A-B is");
        System.out.println(X);
        
        X = A/B;
        System.out.println("the value of A/B is");
        System.out.println(X);
        
        X = A*B;
         System.out.println("the value of A*B is");
         System.out.println(X);
    }
    
}
