
package temprature;
import java.util. Scanner;

public class Temprature {

    public static void main(String[] args) {
     Scanner input = new Scanner(System.in);
     
     double C, F;
     
     System.out.println("please enter value for F");
     F = input.nextDouble();
     
     C = (F-32)*5/9;
      System.out.println(C);
    }
    
}
