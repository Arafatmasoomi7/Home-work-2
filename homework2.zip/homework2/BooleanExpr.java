
package pkgboolean.exp;


public class BooleanExpr {

    
    public static void main(String[] args) {
     
        boolean x = 5<6;
        System.out.println("the result of boolean x is");
        System.out.println(x);
        
        
        boolean y = 7>8;
        System.out.println("the result of boolean y is");
        System.out.println(y);
        
        System.out.println(x && y);
        System.out.println(x || y);
        
        
        
            
    }
    
}
