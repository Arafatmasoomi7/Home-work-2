
package formula.si;
import java.util.Scanner;

public class FormulaSi {

    
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    
    double SI,P, R, T;
    System.out.println("please enter value or P");
    P = input.nextDouble();
    
    System.out.println("please enter value or R");
    R = input.nextDouble();
    
     System.out.println("please enter value or T");
     T = input.nextDouble();
     
     SI = (P*R*T)/100;
      System.out.println("the value of SI is");
      System.out.println(SI);
    }
    
}
